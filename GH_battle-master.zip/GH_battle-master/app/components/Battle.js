const React = require('react');

class Battle extends React.Component {
    render() {
        return (
            <div>
                Battle
            </div>
        )
    }
}

module.exports = Battle;