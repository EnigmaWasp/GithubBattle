const React = require('react');

class Home extends React.Component {
    render() {
        return (
            <div>
                Home
            </div>
        )
    }
}

module.exports = Home;